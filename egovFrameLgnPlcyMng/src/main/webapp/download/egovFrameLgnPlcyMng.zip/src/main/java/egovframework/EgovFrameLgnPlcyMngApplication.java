package egovframework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EgovFrameLgnPlcyMngApplication {

	public static void main(String[] args) {
		SpringApplication.run(EgovFrameLgnPlcyMngApplication.class, args);
	}

}
